<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<script type="text/javascript" src="js/jquery-3.7.1.min.js"></script>
</head>
<body>
	<h1>Selección de servicios</h1>
	<form action="exec.php" method="post">
		<input type="checkbox" id="lamp" name="lamp" value="lamp">
		<label for="lamp"> LAMP</label><br>
		<div id="dLamp" style="display: none;" >
			<input type="text" name="lampDomain" placeholder="Nombre de dominio del servidor para LAMP">
			<input type="password" name="lampMysqlRootPass" placeholder="Contraseña root de MySQL para servidor LAMP">
		</div>
		<br>		
		<input type="checkbox" id="wp" name="wp" value="wp">
		<label for="wp">Wordpress</label><br>
		<div id="dwp" style="display: none;" >
			<input type="text" name="wpDomain" placeholder="Nombre de dominio del servidor para Wordpress">
			<input type="password" name="wpMysqlRootPass" placeholder="Contraseña root de MySQL para el servidor de Wordpress">
		</div>
		<br>
		<input type="checkbox" id="nc" name="nc" value="nc">
		<label for="nc">Nextcloud</label><br>
		<div id="dnc" style="display: none;" >
			<input type="text" name="ncDomain" placeholder="Nombre de dominio del servidor para Nextcloud">
			<input type="password" name="ncMysqlRootPass" placeholder="Contraseña root de MySQL para el servidor de Nextcloud">
		</div>
		<br>
		<div id="dftpu" style="display: none;" >
			<input type="text" name="ftpu" placeholder="Nombre de usuario ftp">
		</div>
		<br>

		<input type="submit" value="Instalar servicios">
	</form>
	<script type="text/javascript">
		$(document).ready(function() {
			$("#lamp").click(function() {
				if($(this).is(":checked")) {		
		        	$('#dLamp').show();
    			} else {
		        	$('#dLamp').hide();    				
    			}
			});		
			$("#wp").click(function() {
				if($(this).is(":checked")) {		
			    	$('#dwp').show();
				} else {
			    	$('#dwp').hide();    				
				}
			});	
			$("#nc").click(function() {
				if($(this).is(":checked")) {		
			    	$('#dnc').show();
				} else {
			    	$('#dnc').hide();    				
				}
			});		

		  $("#lamp, #wp, #nc").click(function() {
		        // Verifica si al menos uno de los checkboxes está seleccionado
		        if($("#lamp").is(":checked") || $("#wp").is(":checked") || $("#nc").is(":checked")) {
		            $('#dftpu').show(); 
		        } else {
		            $('#dftpu').hide(); 
		        }
				});		
	</script>
</body>
</html>